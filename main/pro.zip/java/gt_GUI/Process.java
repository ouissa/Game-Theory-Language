/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gt_GUI;

import parser.Lexer;
import parser.Parser;
import lang_classes.Game;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import lang_classes.NashNotFoundException;
import lang_classes.Pair;
import lang_classes.Player;

/**
 *
 * @author supernova
 */
public class Process {
    public static void parseThing() throws IOException{
        
        // The path to the text file containing the source code.
        
        String PATH = System.getProperty("user.home") + "/code.txt";

        //File destined for the translator.
        String translatorFilePath= System.getProperty("user.home") + "/translatorFile.txt";

        //A buffer to read through the file.
        BufferedReader reader;

        Lexer lexer= new Lexer();

        String tokenizedLine;
        String lineToBeTraslated;

        //File writer to the translatorFile.txt
        FileWriter translatorFileWriter = new FileWriter(translatorFilePath, false);

        //Flag that is set to false in case of a parsing error.
        boolean flag=true;

        try {
            reader = new BufferedReader(new FileReader(PATH));
            String line = reader.readLine();
            Parser parser=new Parser();

            //Checking whether the read line is empty of a comment (starting with '//').
            while (line != null && flag) {
                if(!line.isEmpty() && !isComment(line)) {
                    //parser
                    //System.out.println(line);
                    //System.out.println("\t"+parser.parseLine(line));

                    //If approved by the parser, the line will be written to translatorFile.txt, else the program will stop.
                    if(parser.parseLine(line)){
                        //TRANSLATOR
                        //Tokenize the line and writes it to the file destined for the TRANSLATOR.
                        lineToBeTraslated = lexer.lineTokenizerTranslator(line);
                        translatorFileWriter.write(lineToBeTraslated);
                        translatorFileWriter.write("\n");
                    }else{
                        //Parsing has failed. program need to stop.
                        System.err.println("PARSING ERROR: PROGRAM STOPPED");
                        flag=false;
                    }
                }
                // read next line
                line = reader.readLine();
            }
            reader.close();
            translatorFileWriter.close();

        } catch (IOException e) {
            e.printStackTrace();
        }


        //For any further processing flag must be checked (parsing went without any issues).
        if(flag){

            System.out.println("SUCCESSFUL PARSING");

        }

    }

    //Function that takes a line and determines whether it's a comment (starts with '//') or not.
    public static boolean isComment(String line){
        char[] ch = line.toCharArray();
        if(ch[0]=='/' && ch[1]=='/'){
            return true;
        }
        return false;
    }
    
    public static String charRemover(String str, int p) {  
              return str.substring(0, p) + str.substring(p + 1);  
           }
    
    public static void translate() throws FileNotFoundException, IOException {
        
        int playervar=0;
        int strategyvar=0;
        int i = 0;
        int flag=0;
        String[] USERdef;
        String userd;
        
        String translatorFilePath= System.getProperty("user.home") + "/translatorFile.txt";
        
        String outputPath= System.getProperty("user.home") + "/output.txt";
        
       
        FileReader fr= new FileReader(translatorFilePath);
        BufferedReader br=new BufferedReader(fr);
        StringBuffer sb=new StringBuffer();
        
        
        FileWriter writer = new FileWriter(outputPath);
        BufferedWriter bw = new BufferedWriter(writer);
       
        String line;
        ArrayList<Pair> paretoList = new ArrayList<>();
        ArrayList<Pair> nash_equi = new ArrayList<Pair>();
        ArrayList<Integer> best_res = new ArrayList<>();
        String[] st = {};
       
        line=br.readLine();
        while(line !=null)    
        {  
            if(flag==1){
            sb.delete(0,sb.length());
            }
           sb.append(line);
           String l=sb.toString();
           String[] elem = l.split("\\s+");
           System.out.println(elem[0]);
       
        Player player1 = new Player("tfu", null);
        Player player2 = new Player("tfu", null);
        Game game = new Game("nbgue", player1, player2,null);
        ArrayList<String> strategies1;
        ArrayList<String> strategies2;
        System.out.println(elem.length);
        switch(elem[0]){
             case "GAME":
                 USERdef=elem[1].split(":");
                 
                 userd=USERdef[1];
               
                 System.out.println("ha ana " + userd);
                 game.setName(userd);
                 
                 break;
             case "PLAYER":
                 System.out.println("new player");
                 USERdef=elem[1].split(":");
                 userd=USERdef[1];
                 System.out.println(userd);
                 if(playervar==0){
                    player1.setName(userd);
                 }else{
                    player2.setName(userd);
                 }
                 playervar++;
                 break;
             case "STRATEGY":
                 USERdef=elem[1].split(":");
                 userd=USERdef[1];
                 System.out.println(userd);
                 String[] strategies=USERdef[2].split(",");
              
                 
                 for(int k=0;k<strategies.length;k++){
                     if(k==0){
                         st[k]=charRemover(strategies[0],0);
                     }else if(k==strategies.length-1){
                         st[k]=charRemover(strategies[k],strategies[k].length()-1);
                     }
                     st[i]=strategies[i];
                 }
                System.out.println("kkkk" + st[0]);
                 strategyvar++;
                 break;

             case "OUTCOMES":
                 int val=0;
                 USERdef=elem[1].split(":");
                 userd=USERdef[1];
                 
                 String[] m=USERdef[2].split(",");
                 int count=0;
                 while(!m[count].contains("]")){
                     count++;
                 }
                 int column=count+1;
                 String[][] OutcomeMatrix = new String[m.length/column][column];
                 for (int row = 0; row < m.length/column; row++){
                     for(int j=0; j<column;j++){
                        m[val].substring(1,m[val].length()-1);
                         
                         OutcomeMatrix[row][j]=m[val];
                         
                         val++;
                     }
                 }
                 ArrayList<ArrayList<Pair>> outcomes = new ArrayList<ArrayList<Pair>>();
                for(int h = 0; h < 4; ++h){
                ArrayList<Pair> row = new ArrayList<>();
                    for(int j = 0 ; j < 3; ++j){
                        String[] pair = OutcomeMatrix[h][j].split("/",0);
                        row.add(new Pair(Integer.valueOf(pair[0]),Integer.valueOf(pair[1])));    
                    }

                outcomes.add(row);
  
                }  
                game.setOutcomes(outcomes);
                
                 bw.write(m.length/column);
                 bw.newLine();
                 bw.write(column);
                 bw.newLine();
                 for (int row = 0; row < m.length/column; row++){
                     for(int j=0; j<column;j++){
                      bw.write(OutcomeMatrix[row][j]);
                      bw.newLine();
                     }
                 }
                 break;
             case "ASSOCIATE":
                 USERdef=elem[1].split(":");
                 String userdp=USERdef[1]; //for player
                 String userds=USERdef[2]; //for strategy
                 //stg
                 break;
             case "LINK":
                //stg
                 break;
             case "PARETO":
                 String strPareto = "pareto: ";
               
                 for(Pair p : game.pareto()){
                        strPareto += ("(" + (p.getElement(0)) + "," +  (p.getElement(1)) + ")") + " ";
                 }
                 bw.write(strPareto);
                 bw.newLine();
                 break;
             case "BEST_RESPONSE":
                 int choice1 = 0;
                 int choice2 = 0;
                 USERdef = elem[1].split(":");
                 String oneplayer= USERdef[1];
                 String twoplayer= USERdef[2];
                 String strategyused= USERdef[3];
                 for(int u=0;u<2;u++){
                     if(oneplayer.equals(game.getPlayers()[u].getName())){
                          choice1=u;
                       
                         
                     }
                     if(twoplayer.equals(game.getPlayers()[u].getName())){
                          choice2=u;
                     }
                 }
                 String strBest = "";
                 ArrayList<Integer> best = game.best_response(choice1,choice2, strategyused);
                 bw.write("best response : ");
                 for(int ii: best){
                 // the zero in the following is because it is the player zero that looks for the best response
                 strBest += game.getPlayers()[0].getStrategies().get(ii) + " ";
                 }
                 bw.write(strBest); 
                 bw.newLine();
             case "NASH":
                 
                 String strNash = "";
                 try{
                    // u just need to copy the thing in here and then just copy paste this code
                ArrayList<Pair> nash;
                nash = game.nash();
                bw.write("nash: ");
                for(Pair p : nash){
                    strNash += ("(" + (game.getPlayers())[0].getStrategies().get(p.getElement(0)) + "," +  (game.getPlayers())[1].getStrategies().get(p.getElement(1)) + ")") + " ";
                }
        
                bw.write(strNash);
                bw.newLine();
                }catch(NashNotFoundException e){
                    bw.write(e.getMessage());
                    bw.newLine();
                 }

                 break;
             
        }    
                                                            
        flag=1;
         line=br.readLine();
        }  
        
        bw.close();
       
    }
    
    }

