/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lang_classes;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author supernova
 */
public class Game_test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws NashNotFoundException {
        // TODO code application logic here
        ArrayList<String> str = new ArrayList<>();
        
        str.add("x");
        str.add("y");
        str.add("z");
        
        ArrayList<String> str2 = new ArrayList<>();
        
        str2.add("a");
        str2.add("b");
        str2.add("c");
        str2.add("d");
        
        Player pl1 = new Player("pl1", str2);
        Player pl2 = new Player("pl2", str);
        
        ArrayList<ArrayList<Pair>> outcomes = new ArrayList<ArrayList<Pair>>();
        
        Scanner sc = new Scanner(System.in);

        Pair [][] out = {
            {new Pair(1,2),new Pair(2,2),new Pair(5,1)},
            {new Pair(4,2),new Pair(3,5),new Pair(3,3)},
            {new Pair(5,2),new Pair(4,4),new Pair(7,0)},
            {new Pair(2,3),new Pair(0,4),new Pair(3,0)}
        };
        
        
     
       ArrayList<Pair> added = new ArrayList<>();

       
       for(int i = 0; i < 4; ++i){
            ArrayList<Pair> row = new ArrayList<>();
            for(int j = 0 ; j < 3; ++j){
              
                row.add(out[i][j]);      
               
            }
            
            
            outcomes.add(row);
         
          
       }    
 
        Game gm = new Game("myGame",pl1, pl2, outcomes );
        System.out.println(gm.pareto());
        System.out.println("best " + gm.best_response(0,1,"y"));
        //System.out.println(gm);
        try{
        ArrayList<Pair> nash = gm.nash();
        System.out.println("nash: ");
        for(Pair p : nash){
            System.out.println(p);
        }
        
        }catch(NashNotFoundException e){
            System.out.println(e.getMessage());
        }
        
    

    }
    
}
